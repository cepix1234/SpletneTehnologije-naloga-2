<?php
$_SESSION["id"] = 0;

?>