Uporabniki:
	Uporabni�ko ime: test
	Geslo: test

	Uporabni�ko ime: blaz
	Geslo: blaz

Za pravilno delovanje izbiranje profilnih slik v datoteki php.ini omogocite file_transfers